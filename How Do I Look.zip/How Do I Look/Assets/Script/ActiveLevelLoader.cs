using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ActiveLevelLoader : MonoBehaviour
{
   void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.name.Equals ("Player"))
        {
            LoadCurrenetLevel();
        }
        
    }

    public void LoadCurrenetLevel()
    {
         SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
