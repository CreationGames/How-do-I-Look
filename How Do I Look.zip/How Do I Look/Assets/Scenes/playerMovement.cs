﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovement : MonoBehaviour
{
	public Joystick joyStick;
    public movement controller;
	public float runSpeed = 40f;

	float horizontalMove = 0f;
	public bool jump = false;
	bool Crouch = false;
	

	// Update is called once per frame
	void Update () {

		if (joyStick.Horizontal >= .2f)
		{
			horizontalMove = runSpeed;
		}else if (joyStick.Horizontal <= -.2f)
		{
			horizontalMove = -runSpeed;
		}else
		{
			horizontalMove = 0f;
		} 

		float verticalMove = joyStick.Vertical;

		if (verticalMove >= .5f)
		{
			jump = true;
		} 

	}

	void FixedUpdate ()
	{
		// Move our character
		controller.Move(horizontalMove * Time.fixedDeltaTime, Crouch, jump);
		jump = false;
        Crouch = false;
       
	}
}

